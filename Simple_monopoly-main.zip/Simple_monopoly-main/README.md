# Simple_monopoly
mini project : CLI based monopoly
required packages: py312-game random

before playing,
use 'python3 -m venv venv'
'source venv/bin/activate'
'pip install pygame' or 'pip3 install pygame'
to create environment